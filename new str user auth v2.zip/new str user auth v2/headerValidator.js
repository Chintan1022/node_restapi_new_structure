const dbConn = require('../config/database')
const cryptoLib = require('cryptlib');
const shaKey = cryptoLib.getHashSha256(process.env.KEY, 32);
const common = require('../config/common');



//methods that do not check token
const bypassMethod = new Array("login");

//method that not require api key
const bypassHeaderKey = new Array("sendnotification");

var headerValidator = {

    //Function to validate API key of header (Note : Header keys are encrypted)
    validateHeaderApiKey: async (req,res,next) => {
        const api_key = (req.headers['api-key'] != undefined && req.headers['api-key'] != '') ? cryptoLib.decrypt(req.headers['api-key'], shaKey, process.env.IV) : "";
        const path_data = req.path.split("/");
        if (bypassHeaderKey.indexOf(path_data[2]) === -1) {
            if (api_key == process.env.API_KEY) {
                next()
            } else {
                return await common.sendResponse(req, res, 401, 'rest_keywords_invalid_api_key', null);
            }
        } else {
            return await common.sendResponse(req, res, 500, 'rest_keywords_api_key_not_found_something_wrong', null);
        }
    },

    //Function to validate the token of any user before every request
    validateHeaderToken: async (req,res,next) => {
        var path_data = req.path.split("/");
        if (bypassMethod.indexOf(path_data[2]) === -1) {
            if (req.headers['token'] && req.headers['token'] != '') {
                var headtoken = cryptoLib.decrypt(req.headers['token'], shaKey, process.env.IV).replace(/\s/g, '');
                if (headtoken !== '') {
                     try {
                        const [rows, fields] = await dbConn.query(`SELECT * FROM tbl_user_device WHERE token = ? `, [headtoken]);
                        if (rows.length > 0) {
                            req.user_id = rows[0].user_id;
                            next()
                        }
                        else {
                            return await common.sendResponse(req, res, 401, 'rest_keywords_tokeninvalid', null);
                        }
                    } catch (error) {
                        return await common.sendResponse(req, res, 401, 'rest_keywords_tokeninvalid', null);
                    }
                }
                else {
                    return await common.sendResponse(req, res, 401, 'rest_keywords_tokeninvalid', null);
                }
            } else {
                return await common.sendResponse(req, res, 401, 'rest_keywords_tokeninvalid', null);
            }
        } else {
         next()

        }
    },

     




}
module.exports = headerValidator