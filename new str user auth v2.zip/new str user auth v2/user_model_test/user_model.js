const dbConn = require("../../../config/database");
const common = require("../../../config/common");
const { request } = require("express");
var cryptoLib = require("cryptlib");
const { editProfile } = require("./user_controllers");
var shaKey = cryptoLib.getHashSha256(process.env.KEY, 32);

var user_model = {

    async login(req, res) {
        try {
            const result = await common.decryption(req.body)
            const [rows, fields] = await dbConn.query("SELECT * FROM tbl_user WHERE email = '" + result.email + "' AND is_deleted = 0 ");
            if (rows.length > 0) {
                if (rows[0].is_active == 1) {
                    var password = cryptoLib.decrypt(rows[0].password, shaKey, process.env.IV);
                    if (password === result.password) {
                        var upd_params = {
                            is_online: "1",
                            last_login: require('node-datetime').create().format('Y-m-d H:M:S')
                        }
                        result.user_id = rows[0].id
                        var checkDeviceInfo = await common.checkDeviceInfo(result);
                        var userprofile = await user_model.updateUserDetails(upd_params,result.user_id);
                        checkDeviceInfo.token = userprofile.token;
                        return await common.sendResponse(req, res, 200, 'text_user_login_succ', userprofile);
                    }
                    else{
                        return await common.sendResponse(req, res, 401, 'text_user_incorrect_password',null);
                    }
                }
                else{
                    return await common.sendResponse(req,res,401, 'text_user_account_inactive',null)
                }
               
            }
            else {
            return await common.sendResponse(req, res, 401, 'text_user_invalid_login_details', null);
            }
        } 
        catch (error) {
            return await common.sendResponse(req, res, 500, 'text_user_something_wrong', error);
        }
    },

    async logout(req,res){
        console.log("-------------------",req.user_id);
        try {
            var upd_params ={
                is_online : 0
            }
            var userprofile = await user_model.updateUserDetails(upd_params,req.user_id);
            if(userprofile != null){
             const [rows, fields] = await dbConn.query(`UPDATE tbl_user_device SET token = '',device_token = '' WHERE user_id = ${req.user_id}`);
                if(rows.affectedRows != 0){
                    return await common.sendResponse(req, res, 200, 'text_user_logout_succ', null);
                }
            }
        } catch (error) {
            return await common.sendResponse(req, res, 500, 'text_user_something_wrong', error);
            
        }
    },

    async editProfile(req,res){
            const request = await common.decryption(req.body)
            var userprofile = await user_model.userDetails(req.user_id)
            if(userprofile != null)
            {
                var updparams = {
                    name: request.name,
                    email:request.email
                };
                var updateuserprofile = await user_model.updateUserDetails(updparams,req.user_id)
                return await common.sendResponse(req, res, 200, 'text_user_edit_profile_succ', updateuserprofile);
            }
            else{
                return await common.sendResponse(req, res, 401, 'text_user_not_found', null);
            }
    },


   

    async userDetails(req, res) {
        const [rows, fields] = await dbConn.query("SELECT u.*,ut.device_token as device_token,ut.device_type as device_type,ut.token as token FROM tbl_user u LEFT JOIN tbl_user_device as ut ON u.id = ut.user_id WHERE u.id = '" + req + "' AND u.is_active='1' AND u.is_deleted='0' GROUP BY u.id order by u.id desc");
        if (rows.length > 0) {
            return rows;
        }
        else {
            return false;
        }

    },

    updateUserDetails: async(req,user_id,res) => {
        try {
            const [rows, fields] = await dbConn.query(`UPDATE tbl_user SET ? WHERE id = ${user_id} `,req);
            if (rows.affectedRows != 0) {
                return await user_model.userDetails(user_id)
            }
        } catch (error) {
            console.log(error)
        }
        
    },
}

module.exports = user_model;