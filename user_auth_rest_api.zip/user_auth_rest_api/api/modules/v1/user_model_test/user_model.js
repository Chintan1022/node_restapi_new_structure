const dbConn = require("../../../config/database");
const common = require("../../../config/common");
const { request } = require("express");
var cryptoLib = require("cryptlib");
var shaKey = cryptoLib.getHashSha256(process.env.KEY, 32);

var user_model = {

    async login(req, res) {
        try {
            const result = await common.decryption(req.body)
            const [rows, fields] = await dbConn.query("SELECT * FROM tbl_user WHERE email = '" + result.email + "' AND is_deleted = 0 ");
            if (rows.length > 0) {
                if (rows[0].is_active == 1) {
                    var password = cryptoLib.decrypt(rows[0].password, shaKey, process.env.IV);
                    if (password === result.password) {
                        var upd_params = {
                            is_online: "1",
                            last_login: require('node-datetime').create().format('Y-m-d H:M:S')
                        }
                        result.user_id = rows[0].id
                        var DeviceInfo = await common.checkUpdateDeviceInfo(result);
                        var userprofile = await common.updateUserDetails(upd_params);
                        var Token = await user_model.generateSessionCode(DeviceInfo);
                        userprofile.token = Token;
                        return await common.sendResponse(req, res, 200, 'text_user_login_succ', userprofile);
                    }
                    else{
                        return await common.sendResponse(req, res, 401, 'text_user_incorrect_password',null);
                    }
                }
                else{
                    return await common.sendResponse(req,res,401, 'text_user_account_inactive',null)
                }
               
            }
            else {
            return await common.sendResponse(req, res, 401, 'text_user_invalid_login_details', null);
            }
        } 
        catch (error) {
            return await common.sendResponse(req, res, 500, 'text_user_something_wrong', error);
        }
    },


   

    async userDetails(req, res) {
        const [rows, fields] = await dbConn.query("SELECT u.*,IFNULL(ut.device_token,'') as device_token,IFNULL(ut.device_type,'') as device_type,IFNULL(ut.token,'') as token FROM tbl_user u LEFT JOIN tbl_user_device as ut ON u.id = ut.user_id WHERE u.id = '" + req.user_id + "' AND u.is_active='1' AND u.is_deleted='0' GROUP BY u.id order by u.id desc");
        if (rows.length > 0) {
            return true;
        }
        else {
            return false;
        }

    },





}

module.exports = user_model;