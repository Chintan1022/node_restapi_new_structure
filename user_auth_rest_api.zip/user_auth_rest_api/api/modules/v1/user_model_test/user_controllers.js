const common = require("../../../config/common");
const user_model = require("./user_model");

exports.login = async (req, res) => {
    console.log("------------------------------->",req);

    var request = await common.decryption(req.body);
    var rules = {
        email: "required|email",
        password: "required",
        device_name:'required',
        device_type: 'required|in:A,I',
        device_token: 'required',
        
    }
    let valid = await common.checkValidationRules(request,rules)
    if(valid.status){
        return await user_model.login(req,res)
    }
    else{
        return await common.sendvalidationResponse(res, 422, valid.error, null);
    }
};

exports.logout = async (req, res) => {
    return await user_model.logout(req,res)

};

exports.editProfile = async (req, res) => {

    var request = await common.decryption(req.body);
    var rules = {
        name: "required",
        email: "required|email",
    }
    let valid = await common.checkValidationRules(request,rules)
    if(valid.status){
           return await user_model.editProfile(req,res)
    }
    else{
        return await common.sendResponse1(res, 422, valid.error, null);
    }       
};