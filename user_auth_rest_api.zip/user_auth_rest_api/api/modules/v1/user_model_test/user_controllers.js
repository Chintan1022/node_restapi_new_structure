const common = require("../../../config/common");
const user_model = require("./user_model");

exports.login = async (req, res) => {

    let request = await common.decryption(req.body);
   
   
    var rules = {
        email: "required|email",
        password: "required",
        device_name:'required',
        device_type: 'required|in:A,I',
        device_token: 'required',
        
    }

    let valid = await common.checkValidationRules(request,rules)
    if(valid.status){
        return await user_model.login(req,res)
    }
    else{
        return await common.sendResponse1(res, 422, valid.error, null);
    }
};

