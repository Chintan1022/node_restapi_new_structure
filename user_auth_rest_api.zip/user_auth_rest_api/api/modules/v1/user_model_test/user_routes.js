const express = require('express')
const router = express.Router()
const userController =  require('./user_controllers');


// Retrieve all users
router.post('/login', userController.login);

router.post('/logout', userController.logout);

router.post('/editProfile', userController.editProfile);





module.exports = router;