const cryptoLib = require('cryptlib');
const shaKey = cryptoLib.getHashSha256(process.env.KEY, 32);
const lang = require("./language");
const Validator = require('Validator');
const dbConn = require("../config/database");

const common = {

    sendResponse: async (req, res, resCode, msgKey, resData) => {
      
        const language = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "en-US,en;q=0.9,gu;q=0.8") ? req.headers['accept-language'] : 'en';
        if (lang[language] != undefined && lang[language][msgKey] != undefined) {
            msgKey = lang[language][msgKey]
        }
        var responsejson =
        {
            "message": msgKey

        }
        if (resData != null) {
            responsejson["data"] = resData;
        }
        const result = await common.encryption(responsejson);
        res.status(resCode).send(result)
    },

    sendResponse1: async (res,resCode, msgKey, resData) => {
        
        var responsejson =
        {
            "message": msgKey

        }
        if (resData != null) {
            responsejson["data"] = resData;
        }
        const result = await common.encryption(responsejson);
        res.status(resCode).send(result)

    },

    decryption: async (req, res) => {
        try {
            if (req != undefined && Object.keys(req).length !== 0) {
                let dec_obj = await cryptoLib.decrypt(req, shaKey, process.env.IV)
           
                return JSON.parse(dec_obj);
            }
            else {
                return {}
            }
        } catch (error) {
            return {}

        }
    },

    encryption: async (json_data) => {
        return await cryptoLib.encrypt(JSON.stringify(json_data), shaKey, process.env.IV);
    },

    checkValidationRules: async (request, rules)=> {
         var v = Validator.make(request, rules);
        var _validator = {
            status:true,
        }
        if (v.fails()) {
            var Validator_errors = v.getErrors();
            _validator.status=false
            for (var key in Validator_errors) {
                _validator.error = Validator_errors[key][0];
                break;
            }
        } 
        return _validator;
    },

    checkDeviceInfo: async(req,res) => {
            console.log("checkDeviceInfo",req)
            try {
                var randtoken = require('rand-token').generator();
                var token = randtoken.generate(64, "0123456789abcdefghijklnmopqrstuvwxyz");
                var upd_device = {
                    token: token,
                    uuid: (req.uuid != undefined) ? req.uuid : "",
                    ip: (req.ip != undefined) ? req.ip : "",
                    os_version: (req.os_version != undefined) ? req.os_version : "",
                    model_name: (req.model_name != undefined) ? req.model_name : "",
                    device_name: req.device_name,
                    device_type: req.device_type,
                    device_token: req.device_token,
                };
                const [rows, fields] = await dbConn.query(`SELECT * FROM tbl_user_device WHERE user_id = ${req.user_id}`);
                
                if (rows.length != 0) {
                    const [rows, fields] = await dbConn.query(`UPDATE tbl_user_device SET ? WHERE user_id = ${req.user_id}`, upd_device);
                    console.log("updateDeviceInfo",rows);
                    if (rows.affectedRows != 0) {
                        return upd_device;
                    }
                }
                else{
                    upd_device.user_id = req.user_id;
                    const [rows, fields] = await dbConn.query(`INSERT INTO tbl_user_device SET ?`,upd_device );
                    if (rows.length > 0) {
                        return upd_device;
                    }
                }
            } catch (error) {
                console.log(error);
            }
            
    },






}




module.exports = common;