const dbConn = require('../config/database')
const CryptoJS = require("crypto-js");
const SECRET = CryptoJS.enc.Hex.parse(process.env.KEY);
const IV = CryptoJS.enc.Hex.parse(process.env.IV);
const common = require('../config/common');
const lang = require("../config/language");

//methods that do not check token
const bypassMethod = new Array("login","register","forgotPassword","verifyOtp");

//method that not require api key
const bypassHeaderKey = new Array("sendnotification");



var headerValidator = {

    //function for extract accept language from request header and set in req globaly
    extractHeaderLanguage:async(req,res,next)=>{
        var language = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != '') ? req.headers['accept-language'] : "en";    
        req.language = language;
        next()
    },

    //Function to validate API key of header (Note : Header keys are encrypted)
    validateHeaderApiKey: async (req,res,next) => {
       // var api_key = CryptoJS.AES.decrypt(req.headers['api-key'],SECRET,{iv:IV}).toString(CryptoJS.enc.Utf8) 
       var api_key = await common.decryptPlain(req.headers['api-key']) 

        const path_data = req.path.split("/");
        if (bypassHeaderKey.indexOf(path_data[2]) === -1) {
            if (api_key == process.env.API_KEY) {
                next()
            } else {
                return await common.sendResponse(res, 401, lang[req.language]['rest_keywords_invalid_api_key'], null);
            }
        } else {
            return await common.sendResponse(res, 500, lang[req.language]['rest_keywords_api_key_not_found_something_wrong'], null);
        }
    },

    //Function to validate the token of any user before every request
    validateHeaderToken: async (req,res,next) => {
        var path_data = req.path.split("/");
        if (bypassMethod.indexOf(path_data[2]) === -1) {
            if (req.headers['token'] && req.headers['token'] != '') {
               // var headtoken = CryptoJS.AES.decrypt(req.headers['token'],SECRET,{iv:IV}).toString(CryptoJS.enc.Utf8);
               var headtoken = await common.decryptPlain(req.headers['token'])
                if (headtoken !== '') {
                     try {
                        const [rows, fields] = await dbConn.query(`SELECT * FROM tbl_user_device WHERE token = ? `, [headtoken]);
                        if (rows.length > 0) {
                            req.user_id = rows[0].user_id;
                            next()
                        }
                        else {
                            return await common.sendResponse(res, 401, lang[req.language]['rest_keywords_tokeninvalid'], null);
                        }
                    } catch (error) {
                        return await common.sendResponse(res, 401, lang[req.language]['rest_keywords_tokeninvalid'], null);
                    }
                }
                else {
                    return await common.sendResponse(res, 401, lang[req.language]['rest_keywords_tokeninvalid'], null);
                }
            } else {
                return await common.sendResponse(res, 401, lang[req.language]['rest_keywords_tokeninvalid'], null);
            }
        } else {
         next()

        }
    },

     




}
module.exports = headerValidator