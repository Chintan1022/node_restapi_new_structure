const express = require('express');
require("dotenv").config();

// create express app
const app = express();

// Setup server port
const port = process.env.PORT || 5000;


/**
 * Code to parse request body
 */
app.use(express.text());
app.use(express.urlencoded({ extended: false}));


const user_model = require('./modules/v1/user_model_test/user_routes');
app.use("/api/v1/users", user_model);

// listen for requests
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});