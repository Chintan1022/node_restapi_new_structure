const { request } = require("express");
const common = require("../../../config/common");
const lang = require("../../../config/language");
const user_model = require("./user_model");

exports.getUsers = (req, res, next) => {
  req.language = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "en-US,en;q=0.9,gu;q=0.8") ? req.headers['accept-language'] : 'en';
  user_model.getUsers(req).then((result) => {
    console.log("result",result)
      common.sendResponse(res, 200, lang[req.language]['text_user_get_all_users_succ'], result);
    })
    .catch((err) => {
      common.sendResponse(res, 200, lang[req.language]['text_user_get_all_users_fail'], null);
    });
};

exports.createUsers = (req, res, next) => {
  req.language = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "en-US,en;q=0.9,gu;q=0.8") ? req.headers['accept-language'] : 'en';
  common.decryption(req.body).then((request) => {
  let params = request;
    user_model.createUser(params).then((result) => {
      user_model.getUserById(result).then((userdetails) => {
        common.sendResponse(res, 200, lang[req.language]['text_user_create_succ'], userdetails);
      })
     .catch((err) => {
        common.sendResponse(res, 200, lang[req.language]['text_user_create_fail'], null);
      });
    })
   });
};


exports.updateUsers = (req, res, next) => {
  req.language = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "en-US,en;q=0.9,gu;q=0.8") ? req.headers['accept-language'] : 'en';
  common.decryption(req.body).then((request) => {
  request.id=req.params.id  
  let params = request;
    user_model.updateUser(params).then((result) => {
      common.sendResponse(res,200, lang[req.language]['text_user_update_user_succ'], result);
      })
      .catch((err) => {
        common.sendResponse(res,200,lang[req.language]['text_user_update_user_fail'], null);
      });
  });
};

exports.deleteUsers = (req, res, next) => {
  req.language = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "en-US,en;q=0.9,gu;q=0.8") ? req.headers['accept-language'] : 'en';
  common.decryption(req.body).then((request) => {
  request.id=req.params.id  
  let params = request;
    user_model.deleteUser(params).then((result) => {
        common.sendResponse(res,200,lang[req.language]['text_user_delete_user_succ'], result);
      })
      .catch((err) => {
        common.sendResponse(res,200, lang[req.language]['text_user_delete_user_fail'], null);
      });
  });
};





