var dbConn = require("../../../config/database");
const { getUserById } = require("./user_controllers");

var user_model = {

    async getUsers() {
        return new Promise((resolve,reject)=>{
            dbConn.query(`select * from employees`,(err,result)=>{
                console.log("Get User", result)
                if (!err) {
                    resolve(result)
                } else {
                    reject(err)
                }
            });
            
        })
    },

    async createUser(params){
        return new Promise((resolve,reject)=>{
            dbConn.query(`INSERT INTO employees SET ?`,params,(err,result)=>{
                console.log("create User", result)
                if (!err) {
                    resolve(result)
                } else {
                    reject(err)
                }
            });
        })
    },

    async updateUser(params){
        return new Promise((resolve,reject)=>{
            dbConn.query(`UPDATE employees SET ? WHERE id = ${params.id} `,params,(err,result)=>{
                console.log("update User", result)
                if (!err) {
                    resolve(result)
                } else {
                    reject(err)
                }
            });
        })
    },

    async deleteUser(params){
        return new Promise((resolve,reject)=>{
            dbConn.query(`DELETE FROM employees WHERE id = ${params.id}`,params,(err,result)=>{
                console.log("delete User", result)
                if (!err) {
                    resolve(result)
                } else {
                    reject(err)
                }
            });
        })
    },

    async getUserById(result) {
        return new Promise((resolve,reject)=>{
            dbConn.query(`select * from employees where id = ${result.insertId}`,result,(err,result)=>{
                console.log("Get User by id", result)
                if (!err) {
                    resolve(result)
                } else {
                    reject(err)
                }
            });
            
        })
    }

}

module.exports = user_model;