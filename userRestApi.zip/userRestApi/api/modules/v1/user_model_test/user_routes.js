const express = require('express')
const router = express.Router()
const userController =  require('./user_controllers');


// Retrieve all users
router.get('/', userController.getUsers);

//create user
router.post('/', userController.createUsers);

//update user
router.put('/:id', userController.updateUsers);

//delete user
router.delete('/:id', userController.deleteUsers);




module.exports = router;