const cryptoLib = require('cryptlib');
const shaKey = cryptoLib.getHashSha256(process.env.KEY, 32);
const lang = require("./language");
const common = {

 sendResponse : async (res, resCode, resMessage, resData) =>
    {
        
        var response =
        {
            "code" : resCode,
            "message" : resMessage 
        }
        if(resData != null)
        {
            response["data"] = resData;
        }
        common.encryption(response).then((result)=>{
            res.status(resCode);
            res.json(result);
            res.end();
        });
    },
    
    decryption: async (req)=>{
        
        return new Promise((resolve,reject)=>{
            if(req != undefined && Object.keys(req).length !== 0) {
        
                try {
                    var request = JSON.parse(cryptoLib.decrypt(req, shaKey, process.env.IV));
                }
                catch (e) {
                    var request = cryptoLib.decrypt(req, shaKey, process.env.IV);
                }
                resolve(request);
            }
            else {
                resolve({});
            }
        })
    },

    encryption: async (req) => {
        return new Promise((resolve,reject)=>{
            var response = cryptoLib.encrypt(JSON.stringify(req), shaKey, process.env.IV);
            resolve(response);
        })
    },

}

module.exports = common;