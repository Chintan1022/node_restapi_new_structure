const express = require('express');
const router = express.Router();
const middleware = require('../../middleware/headerValidator');

const user_model_test = require('./user_model_test/user_routes');



router.use('/', middleware.extractHeaderLanguage);
router.use('/', middleware.validateHeaderApiKey);
router.use('/', middleware.validateHeaderToken);


router.use('/auth/',user_model_test);


module.exports = router;