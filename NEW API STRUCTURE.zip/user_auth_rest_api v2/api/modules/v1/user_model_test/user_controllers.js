const common = require("../../../config/common");
const user_model = require("./user_model");

exports.register = async (req, res) => {
    var request = await common.decryption(req);
    var rules = {
        name: "required",
        email: "required|email",
        password: "required",
        device_type: 'required|in:A,I',
        device_token: 'required',
        device_name: 'required'

    }
    let valid = await common.checkValidationRules(request, rules)
    if (valid.status) {
        return await user_model.register(request, res)
    }
    else {
        return await common.sendResponse(res, 404, valid.error, null);
    }
};

exports.login = async (req, res) => {
    var request = await common.decryption(req);
    var rules = {
        email: "required|email",
        password: "required",
        device_type: 'required|in:A,I',
        device_token: 'required',
        device_name: 'required'
    }
    let valid = await common.checkValidationRules(request, rules)
    if (valid.status) {
        return await user_model.login(request, res)
    }
    else {
        return await common.sendResponse(res, 404, valid.error, null);
    }
};

exports.logout = async (req, res) => {
    return await user_model.logout(req, res)

};

exports.editProfile = async (req, res) => {
    var request = await common.decryption(req);
    var rules = {
        name: "required",
        email: "required|email",
    }
    let valid = await common.checkValidationRules(request, rules)
    if (valid.status) {
        return await user_model.editProfile(request, res)
    }
    else {
        return await common.sendResponse(res, 404, valid.error, null);
    }
};

exports.forgotPassword = async (req, res) => {
    var request = await common.decryption(req);
    var rules = {
        email: "required|email",
    }
    let valid = await common.checkValidationRules(request, rules)
    if (valid.status) {
        return await user_model.forgotPassword(request, res)
    }
    else {
        return await common.sendResponse(res, 404, valid.error, null);
    }
};

exports.verifyOtp = async (req, res) => {
    var request = await common.decryption(req);
    var rules = {
        email: "required|email",
        otp: "required"
    }
    let valid = await common.checkValidationRules(request, rules)
    if (valid.status) {
        return await user_model.verifyOtp(request, res)
    }
    else {
        return await common.sendResponse(res, 404, valid.error, null);
    }
};

exports.changePassword = async (req, res) => {
    var request = await common.decryption(req);
    var rules = {
        oldpassword:"required",
        newpassword:"required"

    }
    let valid = await common.checkValidationRules(request, rules)
    if (valid.status) {
        return await user_model.changePassword(request, res)
    }
    else {
        return await common.sendResponse(res, 404, valid.error, null);
    }
};

exports.getuserProfile = async (req, res) => {
return await user_model.getuserProfile(req, res)
};


