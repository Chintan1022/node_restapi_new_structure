const dbConn = require("../../../config/database");
const common = require("../../../config/common");
const lang = require("../../../config/language");
const emailTemplate = require("../../../config/template")

var user_model = {

    //function for Register user
    async register(req, res) {
        try {
            const checkUniqueEmail = await common.checkUniqueEmail(req)
            console.log(checkUniqueEmail);
            if (checkUniqueEmail) {
                var user = {
                    name: req.name,
                    email: req.email,
                    password: common.encryptPlain(req.password),
                    is_online: "1",
                    last_login: require('node-datetime').create().format('Y-m-d H:M:S'),
                    latitude: (req.latitude != undefined && req.latitude != "") ? req.latitude : "",
                    longitude: (req.longitude != undefined && req.longitude != "") ? req.longitude : ""

                };
                const [rows, fields] = await dbConn.query(`INSERT INTO tbl_user SET ?`, user);
                console.log(rows);
                if (rows.affectedRows != 0) {
                    req.user_id = rows.insertId
                    var checkDeviceInfo = await common.checkDeviceInfo(req);
                    var userprofile = await user_model.userDetails(req.user_id);
                    checkDeviceInfo.token = userprofile.token;
                    return await common.sendResponse(res, 200, lang[req.language]['text_user_register_succ'], userprofile)
                }

            }
            else {
                return await common.sendResponse(res, 404, lang[req.language]['text_user_duplicate_email'], null)
            }
        }
        catch (error) {
            return await common.sendResponse(res, 500, lang[req.language]['text_user_something_wrong'], error);
        }
    },

    //function for Login user
    async login(req, res) {
        try {
            const [rows, fields] = await dbConn.query("SELECT * FROM tbl_user WHERE email = '" + req.email + "' AND is_deleted = 0 ");
            if (rows.length > 0) {
                if (rows[0].is_active == 1) {
                   // console.log(rows[0]);
                    var password = await common.decryptPlain(rows[0].password)
                    //console.log(password);
                    if (password === req.password) {
                        var upd_params = {
                            is_online: "1",
                            last_login: require('node-datetime').create().format('Y-m-d H:M:S')
                        }
                        req.user_id = rows[0].id
                        var checkDeviceInfo = await common.checkDeviceInfo(req);
                        var userprofile = await user_model.updateUserDetails(upd_params, req.user_id);
                        checkDeviceInfo.token = userprofile.token;
                        return await common.sendResponse(res, 200, lang[req.language]['text_user_login_succ'], userprofile[0]);
                    }
                    else {
                        return await common.sendResponse(res, 404, lang[req.language]['text_user_incorrect_password'], null);
                    }
                }
                else {
                    return await common.sendResponse(res, 404, lang[req.language]['text_user_account_inactive'], null)
                }
            }
            else {
                return await common.sendResponse(res, 404, lang[req.language]['text_user_invalid_login_details'], null);
            }
        }
        catch (error) {
            return await common.sendResponse(res, 500, lang[req.language]['text_user_something_wrong'], error);
        }
    },

    //function for Logout user
    async logout(req, res) {
        try {
            var upd_params = {
                is_online: 0
            }
            var userprofile = await user_model.updateUserDetails(upd_params, req.user_id);
            if (userprofile != null) {
                const [rows, fields] = await dbConn.query(`UPDATE tbl_user_device SET token = '',device_token = '' WHERE user_id = ${req.user_id}`);
                if (rows.affectedRows != 0) {
                    return await common.sendResponse(res, 200, lang[req.language]['text_user_logout_succ'], null);
                }
            }
        } catch (error) {
            return await common.sendResponse(res, 500, lang[req.language]['text_user_something_wrong'], error);

        }
    },

    //function for edit profile
    async editProfile(req, res) {
        var userprofile = await user_model.userDetails(req.user_id)
        if (userprofile != null) {
            var updparams = {
                name: req.name,
                email: req.email
            };
            var updateuserprofile = await user_model.updateUserDetails(updparams, req.user_id)
            return await common.sendResponse(res, 200, lang[req.language]['text_user_edit_profile_succ'], updateuserprofile[0]);
        }
        else {
            return await common.sendResponse(res, 404, lang[req.language]['text_user_not_found'], null);
        }
    },

    //function for forget Password
    async forgotPassword(req, res) {
        try {
            const [rows, fields] = await dbConn.query("SELECT * FROM tbl_user WHERE email = '" + req.email + "' AND is_deleted = 0 AND is_active = 1");
            if (rows.length > 0) {
                var OTP = Math.floor(1000 + Math.random() * 9000);
                req.OTP = OTP;
                const [rows, fields] = await dbConn.query(`SELECT * FROM tbl_user_verification where email = '${req.email}' `);
                if (rows.length > 0) {
                    return await user_model.updateOtp(req, res)
                }
                else {
                    return await user_model.insertOtp(req, res)
                }
            }
            else {
                return await common.sendResponse(res, 404, lang[req.language]['text_user_not_exist'], null);
            }
        }
        catch (error) {
            return await common.sendResponse(res, 500, lang[req.language]['text_user_something_wrong'], error);
        }
    },

    //function for get user details
    async userDetails(req, res) {
        const [rows, fields] = await dbConn.query("SELECT u.*,ut.device_token as device_token,ut.device_type as device_type,ut.token as token FROM tbl_user u LEFT JOIN tbl_user_device as ut ON u.id = ut.user_id WHERE u.id = '" + req + "' AND u.is_active='1' AND u.is_deleted='0' GROUP BY u.id order by u.id desc");
        if (rows.length > 0) {
            return rows;
        }
        else {
            return false;
        }

    },

    //function for update user details
    async updateUserDetails(req, user_id, res) {
        try {
            const [rows, fields] = await dbConn.query(`UPDATE tbl_user SET ? WHERE id = ${user_id} `, req);
            if (rows.affectedRows != 0) {
                return await user_model.userDetails(user_id)
            }
        } catch (error) {
            console.log(error)
        }

    },

    //function for insert otp
    async insertOtp(req, res) {
        var upd_params = {
            email: req.email,
            otp: req.OTP
        }
        const [rows, fields] = await dbConn.query(`INSERT INTO tbl_user_verification SET ?`, upd_params);
        if (rows.affectedRows != 0) {
            var sendotpTemplatemail = await emailTemplate.send_otp(req)
            var sendOtp = await common.send_email("SendOtp", req.email, sendotpTemplatemail)
            if (sendOtp) {
                return await common.sendResponse(res, 200, lang[req.language]['text_user_otp_send_succ'], null);
            }
            else {
                return await common.sendResponse(res, 404, lang[req.language]['text_user_otp_send_fail'], null);

            }
        }
        else {
            return await common.sendResponse(res, 500, lang[req.language]['text_user_something_wrong'], error);

        }

    },

    //function for update otp
    async updateOtp(req, res) {
        console.log(req.language);
        try {
            var upd_params = {
                otp: req.OTP
            }
            const [rows, fields] = await dbConn.query(`UPDATE tbl_user_verification SET ? where email = '${req.email}'`, upd_params);
            if (rows.affectedRows != 0) {
                sendotpTemplatemail = await emailTemplate.send_otp(req)
                var sendOtp = await common.send_email("SendOtp", req.email, sendotpTemplatemail)
                if (sendOtp) {
                    return await common.sendResponse(res, 200, lang[req.language]['text_user_otp_resend_succ'], null);
                }
                else {
                    return await common.sendResponse(res, 404, lang[req.language]['text_user_otp_resend_fail'], null);

                }
            }
        }
        catch (error) {
            console.log("error", error);
            return await common.sendResponse(res, 500, lang[req.language]['text_user_something_wrong'], null);

        }


    },

    //function for verify otp
    async verifyOtp(req, res) {
        try {
            const [rows, fields] = await dbConn.query("SELECT * FROM tbl_user_verification WHERE email = '" + req.email + "' AND otp = '" + req.otp + "' ");
            if (rows.length > 0) {
                const [rows, fields] = await dbConn.query("DELETE FROM tbl_user_verification WHERE email = '" + req.email + "' ");
                {
                    if (rows.affectedRows != 0) {
                        return await common.sendResponse(res, 200, lang[req.language]['text_user_otp_verify_succ'], null);
                    }
                }

            }
            else {
                return await common.sendResponse(res, 404, lang[req.language]['text_user_otp_invalid_otp'], null);

            }
        } catch (error) {
            console.log(error);
            return await common.sendResponse(res, 500, lang[req.language]['text_user_something_wrong'], null);

        }
    },

    //function for forget Password
    async changePassword(req, res) {
        console.log(req);
        try {
            var userprofile = await user_model.userDetails(req.user_id)
            console.log(userprofile);
            if (userprofile[0] != null) {
                var currentpassword = await common.decryptPlain(userprofile[0].password);
                if (currentpassword != req.oldpassword) {
                    return await common.sendResponse(res, 404, lang[req.language]['text_user_old_password_incorrect'], null);
                }
                else if (currentpassword == req.newpassword) {
                    return await common.sendResponse(res, 404, lang[req.language]['text_user_newold_password_similar'], null);
                }
                else {
                    var password = common.encryptPlain(req.newpassword);
                    var updparams = {
                        password: password
                    };
                    var updateuserdetails = await user_model.updateUserDetails(updparams, req.user_id)
                    if (updateuserdetails != null) {
                        return await common.sendResponse(res, 200, lang[req.language]['text_user_change_password_success'], updateuserdetails[0]);
                    }
                }
            }
            else {
                return await common.sendResponse(res, 404, lang[req.language]['text_user_not_found'], null);
            }
        }
        catch (error) {
            return await common.sendResponse(res, 500, lang[req.language]['text_user_something_wrong'], error);
        }
    },

    //function for get profile
    async getuserProfile (req, res){
        try {
            var userprofile = await user_model.userDetails(req.user_id)
            return await common.sendResponse(res, 200, lang[req.language]['text_user_get_user_profile'], userprofile[0]);

        } catch (error) {
            console.log(error);
            return await common.sendResponse(res, 500, lang[req.language]['text_user_something_wrong'], error);

        }
    }
}

module.exports = user_model;