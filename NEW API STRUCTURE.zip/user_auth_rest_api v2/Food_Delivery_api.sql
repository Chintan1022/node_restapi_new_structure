-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 09, 2022 at 09:34 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Food_Delivery_api`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `dish_id` bigint(20) NOT NULL,
  `qty` varchar(16) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`id`, `user_id`, `dish_id`, `qty`, `created_at`, `updated_at`) VALUES
(2, 2, 3, '5', '2022-11-25 05:20:26', '2022-11-25 05:20:26');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` bigint(128) NOT NULL,
  `category_name` varchar(64) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `category_name`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES
(1, 'pizza', 1, 0, '2022-11-22 08:11:43', '2022-11-22 08:11:43'),
(2, 'Burger', 1, 0, '2022-11-22 08:11:43', '2022-11-22 08:11:43'),
(3, 'Italian', 1, 0, '2022-11-22 08:11:43', '2022-11-22 08:11:43'),
(4, 'Chinese', 1, 0, '2022-11-22 08:11:43', '2022-11-22 08:11:43'),
(5, 'Punjabi', 1, 0, '2022-11-22 08:11:43', '2022-11-22 08:11:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dish`
--

CREATE TABLE `tbl_dish` (
  `id` bigint(20) NOT NULL,
  `restaurant_id` bigint(20) NOT NULL,
  `category_id` bigint(20) NOT NULL,
  `image` varchar(256) NOT NULL,
  `dish_name` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `about` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_dish`
--

INSERT INTO `tbl_dish` (`id`, `restaurant_id`, `category_id`, `image`, `dish_name`, `price`, `about`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'p.jpg', 'italian pizza', '120.00', 'asdsodajsdoajsda', 1, 0, '2022-09-08 04:04:20', '2022-09-08 04:04:20'),
(2, 2, 2, 'm.jpg', 'manchurian', '100.00', 'dskadnajskdnaksjndkajsd', 1, 0, '2022-09-08 04:04:20', '2022-09-08 04:04:20'),
(3, 3, 4, 'd.jpg', 'dhokla', '80.00', 'dsadnaskndaknsdasd', 1, 0, '2022-09-08 04:04:20', '2022-09-08 04:04:20'),
(4, 3, 4, 'g.jpg', 'punjabi thali', '180.00', 'dsadkjaskdsakhdsakdjhasd', 1, 0, '2022-09-08 04:04:20', '2022-11-24 05:36:50'),
(5, 4, 3, 'pp.jpg', 'panner pasanda', '180.00', 'sadjsajdasdjosiajd', 1, 0, '2022-09-08 04:04:20', '2022-09-08 22:54:39'),
(6, 4, 3, 'pa.jpg', 'panner angara', '180.00', 'dsadsadasdsadasdsadas', 1, 0, '2022-09-08 04:06:42', '2022-09-08 04:06:42'),
(9, 1, 3, 'pad.jpg', 'panner angara', '150.00', 'sdasdasdasdsadsad', 1, 0, '2022-09-08 04:48:40', '2022-09-08 04:48:40');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_favorite`
--

CREATE TABLE `tbl_favorite` (
  `id` bigint(20) NOT NULL,
  `restaurant_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_favorite`
--

INSERT INTO `tbl_favorite` (`id`, `restaurant_id`, `user_id`, `created_at`, `updated_at`) VALUES
(7, 2, 2, '2022-11-24 04:33:59', '2022-11-24 04:33:59'),
(8, 5, 2, '2022-11-24 04:33:59', '2022-11-24 04:38:32');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_images`
--

CREATE TABLE `tbl_images` (
  `id` bigint(20) NOT NULL,
  `restaurant_id` bigint(20) NOT NULL,
  `image` varchar(64) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_images`
--

INSERT INTO `tbl_images` (`id`, `restaurant_id`, `image`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES
(1, 1, 'decent 1.jpg', 1, 0, '2022-09-08 04:38:50', '2022-09-08 04:38:50'),
(2, 1, 'decent2.jpg', 1, 0, '2022-09-08 04:38:50', '2022-09-08 04:38:50'),
(3, 2, 'cozy.jpg', 1, 0, '2022-09-08 04:38:50', '2022-09-08 04:38:50'),
(4, 3, 'nilkanth.jpg', 1, 0, '2022-09-08 04:38:50', '2022-09-08 04:38:50'),
(5, 4, 'tilak.jpg', 1, 0, '2022-09-08 04:38:50', '2022-09-08 04:38:50'),
(6, 4, 'tilak2.jpg', 1, 0, '2022-09-08 04:38:50', '2022-09-08 04:38:50');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rating`
--

CREATE TABLE `tbl_rating` (
  `id` bigint(128) NOT NULL,
  `user_id` bigint(128) NOT NULL,
  `restaurant_id` bigint(128) NOT NULL,
  `rating` float(2,1) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Triggers `tbl_rating`
--
DELIMITER $$
CREATE TRIGGER `avg_rating` AFTER INSERT ON `tbl_rating` FOR EACH ROW UPDATE tbl_restaurant set avg_rating=(select avg(rating)from tbl_rating where tbl_rating.restaurant_id=tbl_restaurant.id)where id=new.restaurant_id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_restaurant`
--

CREATE TABLE `tbl_restaurant` (
  `id` bigint(20) NOT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `restaurant_name` varchar(50) NOT NULL,
  `location` varchar(256) NOT NULL,
  `avg_rating` float(2,1) NOT NULL DEFAULT 0.0,
  `latitude` varchar(256) NOT NULL,
  `longitude` varchar(256) NOT NULL,
  `estimatedelivery_time` varchar(64) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_restaurant`
--

INSERT INTO `tbl_restaurant` (`id`, `category_id`, `restaurant_name`, `location`, `avg_rating`, `latitude`, `longitude`, `estimatedelivery_time`, `is_active`, `is_deleted`, `created_at`, `updated_at`) VALUES
(1, 5, 'decent restaurant', 'mehsana,gujarat', 4.1, '23.612932', '72.3992852', NULL, 1, 0, '2022-09-06 23:32:11', '2022-11-22 12:11:12'),
(2, 2, 'cozy restaurant', 'mehsana,gujarat', 0.0, '23.5791156', '72.3663636', NULL, 1, 0, '2022-09-06 23:32:11', '2022-11-22 12:10:28'),
(3, 5, 'nilkanth restaurant', 'mehsana,gujarat', 0.0, '23.6123169', '72.3561598', NULL, 1, 0, '2022-09-06 23:32:11', '2022-11-22 12:11:09'),
(4, 3, 'tilak restaurant', 'mehsana,gujarat', 0.0, '23.6207323', '72.3421866', NULL, 1, 0, '2022-09-06 23:32:11', '2022-11-22 12:10:34'),
(5, 1, 'lapinoz', 'mehsana,gujarat', 0.0, '23.6207323', '72.3421866', NULL, 1, 0, '2022-09-06 23:32:11', '2022-11-22 12:10:50'),
(6, 2, 'wow chinese', 'mehsana,gujarat', 0.0, '23.6207323', '72.3421866', NULL, 1, 0, '2022-09-06 23:32:11', '2022-11-22 12:32:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` bigint(20) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_online` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `is_verify` tinyint(1) NOT NULL DEFAULT 0,
  `last_login` datetime NOT NULL,
  `latitude` varchar(64) NOT NULL,
  `longitude` varchar(64) NOT NULL,
  `forgotpassword_token` varchar(128) DEFAULT NULL,
  `forgotpassword_date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `password`, `is_active`, `is_online`, `is_deleted`, `is_verify`, `last_login`, `latitude`, `longitude`, `forgotpassword_token`, `forgotpassword_date`, `created_at`, `updated_at`) VALUES
(2, 'Chintan Soni10', 'sonichintan83@gmail.com', 'WLtixZm44oui1kv4Mlv73w==', 1, 1, 0, 1, '2022-12-09 13:46:23', '23.586761', '72.369949', 'FOODDELIVERYAPI2', '2022-11-21 11:43:03', '2022-11-18 10:59:01', '2022-12-09 08:16:23'),
(16, 'Sikhar Mehta', 'showtimewizard49@gmail.com', 'vqfbE5cxOlOmFJ7HzHPqgg==', 1, 0, 0, 0, '2022-12-07 11:52:06', '', '', NULL, NULL, '2022-12-07 06:22:06', '2022-12-09 06:42:02'),
(18, 'sahil Kanet', 'sahilk49@gmail.com', 'vVHdjO4LIYpT+dn90b1z1Q==', 1, 1, 0, 0, '2022-12-07 15:12:16', '', '', NULL, NULL, '2022-12-07 09:42:16', '2022-12-07 09:42:16'),
(21, 'Anand Swami', 'anand12@gmail.com', 'o2ISzGXCMJxzbzt7c5GyEg==', 1, 1, 0, 0, '2022-12-08 14:56:17', '', '', NULL, NULL, '2022-12-08 09:26:17', '2022-12-08 09:26:17'),
(22, 'tirth g', 'tirth55@gmail.com', 'UslFCox3puhFf/01+dnydw==', 1, 1, 0, 0, '2022-12-09 12:18:27', '', '', NULL, NULL, '2022-12-09 06:48:27', '2022-12-09 06:48:27');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_device`
--

CREATE TABLE `tbl_user_device` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `token` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `device_type` char(1) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '''A''->Android,''I''->Ios',
  `device_token` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `uuid` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `os_version` varchar(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `device_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `model_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_device`
--

INSERT INTO `tbl_user_device` (`id`, `user_id`, `token`, `device_type`, `device_token`, `uuid`, `os_version`, `device_name`, `model_name`, `ip`, `is_active`, `is_deleted`, `insertdate`, `updatetime`) VALUES
(1, 2, 'foplkj64sm94py3udiugs2rsa2ugs4zsqyfgbht34ohpgcehi4e7agup2lzhuniw', 'A', 'jksjdkjsdkjskdjks', '', '', 'redmi note 10 t', '', '', 1, 0, '2022-11-18 10:59:01', '2022-12-09 08:16:23'),
(2, 16, '', 'A', '', '', '', 'samsung a73', '', '', 1, 0, '2022-12-07 06:22:06', '2022-12-09 06:42:02'),
(4, 18, 'k0y507h74j25eyf2qvbgo5l3rklzd8jyaqmgt6esw3bl177cqm9i51nfapptv7so', 'A', 'dadasjodijsad', '', '', 'samsung m32', '', '', 1, 0, '2022-12-07 09:42:16', '2022-12-07 09:42:16'),
(7, 21, 'jlsd8dh67tj2wg7i5p6ujkae1i97y5ltfwwr4dou9zq5tbgmvj1mia7rtb8zgqpk', 'A', 'daasdsaddasjodijsad', '', '', 'samsung m3', '', '', 1, 0, '2022-12-08 09:26:17', '2022-12-08 09:26:17'),
(8, 22, 'rk1v8aragdf0zdl1w1xmrdj87irvy9zv66mz9fj6krx87l8s77t60im40qrud5de', 'A', 'jksjdkjsdkjskdjks', '', '', 'redmi note 8', '', '', 1, 0, '2022-12-09 06:48:27', '2022-12-09 06:48:27');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_verification`
--

CREATE TABLE `tbl_user_verification` (
  `id` bigint(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `otp` varchar(8) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_verification`
--

INSERT INTO `tbl_user_verification` (`id`, `email`, `otp`, `created_at`, `updated_at`) VALUES
(10, 'sonichintan83@gmail.com', '7017', '2022-12-09 07:08:48', '2022-12-09 07:08:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_dish`
--
ALTER TABLE `tbl_dish`
  ADD PRIMARY KEY (`id`),
  ADD KEY `restaurant_id` (`restaurant_id`);

--
-- Indexes for table `tbl_favorite`
--
ALTER TABLE `tbl_favorite`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_restaurant`
--
ALTER TABLE `tbl_restaurant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_user_verification`
--
ALTER TABLE `tbl_user_verification`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` bigint(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_dish`
--
ALTER TABLE `tbl_dish`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_favorite`
--
ALTER TABLE `tbl_favorite`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  MODIFY `id` bigint(128) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_restaurant`
--
ALTER TABLE `tbl_restaurant`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_user_verification`
--
ALTER TABLE `tbl_user_verification`
  MODIFY `id` bigint(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
