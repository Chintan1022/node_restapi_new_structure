const express = require('express')
const router = express.Router()
const userController =  require('./user_controllers');

router.post('/register', userController.register);

router.post('/login', userController.login);

router.post('/logout', userController.logout);

router.post('/forgotPassword', userController.forgotPassword);

router.post('/verifyOtp', userController.verifyOtp);

router.post('/editProfile', userController.editProfile);

router.post('/changePassword', userController.changePassword);

router.get('/getUserProfile', userController.getuserProfile);

module.exports = router;