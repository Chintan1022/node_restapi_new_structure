const lang = require("./language");
const Validator = require('Validator');
const dbConn = require("../config/database");
const CryptoJS = require("crypto-js");
const SECRET = CryptoJS.enc.Hex.parse(process.env.KEY);
const IV = CryptoJS.enc.Hex.parse(process.env.IV);

const common = {

    sendResponse: async (res, resCode, msgKey, resData) => {
        var responsejson =
        {
            "code": resCode,
            "message": msgKey

        }
        if (resData != null) {
            responsejson["data"] = resData;
        }
        const result = await common.encryption(responsejson);
        return res.status(resCode).send(result)
    },

    //decrypt user request
    decryption: async (req, res) => {
        try {
            if (req.body != undefined && Object.keys(req.body).length !== 0) {
                var request = JSON.parse(CryptoJS.AES.decrypt(req.body, SECRET, { iv: IV }).toString(CryptoJS.enc.Utf8))
                request.language = req.language;
                request.user_id = req.user_id
                return request;
            }
            else {
                return {}
            }
        } catch (error) {
            return '';

        }
    },

    

    //encrypt user request
    encryption: async (response_data) => {
        try {
            return CryptoJS.AES.encrypt(JSON.stringify(response_data), SECRET, { iv: IV }).toString();
        } catch (error) {
            return ''
        }
    },


    //function for encrypt plain data  
    encryptPlain: function (data) {
        try {
            return CryptoJS.AES.encrypt(JSON.stringify(data), SECRET, { iv: IV }).toString();
        } catch (e) {
            return '';
        }
    },

    //function for decrypt plain data
    decryptPlain: async (data) => {
        try {
            return JSON.parse(CryptoJS.AES.decrypt(data, SECRET, { iv: IV }).toString(CryptoJS.enc.Utf8));
        } catch (e) {
            return CryptoJS.AES.decrypt(data, SECRET, { iv: IV }).toString(CryptoJS.enc.Utf8);
        }
    },


    //check Validation Rules
    checkValidationRules: async (request, rules) => {
        var v = Validator.make(request, rules);
        var _validator = {
            status: true,
        }
        if (v.fails()) {
            var Validator_errors = v.getErrors();
            _validator.status = false
            for (var key in Validator_errors) {
                _validator.error = Validator_errors[key][0];
                break;
            }
        }
        return _validator;
    },
    
    //check,update,insert user device details
    checkDeviceInfo: async (req, res) => {
        try {
            var randtoken = require('rand-token').generator();
            var token = randtoken.generate(64, "0123456789abcdefghijklnmopqrstuvwxyz");
            var upd_device = {
                token: token,
                uuid: (req.uuid != undefined) ? req.uuid : "",
                ip: (req.ip != undefined) ? req.ip : "",
                os_version: (req.os_version != undefined) ? req.os_version : "",
                model_name: (req.model_name != undefined) ? req.model_name : "",
                device_name: req.device_name,
                device_type: req.device_type,
                device_token: req.device_token,
            };
            const [rows, fields] = await dbConn.query(`SELECT * FROM tbl_user_device WHERE user_id = ${req.user_id}`);
            if (rows.length > 0) {
                const [rows, fields] = await dbConn.query(`UPDATE tbl_user_device SET ? WHERE user_id = ${req.user_id}`, upd_device);
                if (rows.affectedRows != 0) {
                    return upd_device;
                }
            }
            else {
                upd_device.user_id = req.user_id;
                const [rows, fields] = await dbConn.query(`INSERT INTO tbl_user_device SET ?`, upd_device);
                if (rows.affectedRows != 0) {
                    return upd_device;
                }
            }
        } catch (error) {
            console.log(error);
        }

    },

    //function for check unique email
    checkUniqueEmail: async (req, res) => {
        try {
            const [rows, fields] = await dbConn.query(`SELECT * FROM tbl_user WHERE email = '${req.email}' AND is_deleted = 0 AND is_active = 1 `);
            if (rows.length > 0) {
                return false;
            }
            else {
                return true;
            }
        } catch (error) {
            return await common.sendResponse(res, 500, lang[req.language]['text_user_something_wrong'], null)
        }
    },

    //function for send email
    send_email: async (subject, to_email, message) => {
        try {
            var nodemailer = require('nodemailer');
            var transporter = nodemailer.createTransport({
                host: 'smtp.gmail.com',
                port: 587,
                secure: false,
                auth: {
                    user: process.env.EMAIL_ID,
                    pass: process.env.EMAIL_PASSWORD
                }
            });
            var mailOptions = {
                from: process.env.EMAIL_ID,
                to: to_email,
                subject: subject,
                html: message
            };
            return await transporter.sendMail(mailOptions)
        } 
        catch (error) {
            console.log(error);
        }
        
    },
}




module.exports = common;