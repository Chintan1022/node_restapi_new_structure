const CryptoJS = require("crypto-js");
require("dotenv").config();
const SECRET = CryptoJS.enc.Hex.parse(process.env.KEY);
const IV = CryptoJS.enc.Hex.parse(process.env.IV);   
   
var enc_dec = {  

  decryptionDemo: function (req, res) {
    var request = JSON.parse(
      CryptoJS.AES.decrypt(req, SECRET, { iv: IV }).toString(CryptoJS.enc.Utf8)
    );
    res.json(request);
  },

  encryptionDemo: function (req, res) {
    var encrypted = CryptoJS.AES.encrypt(req, SECRET, { iv: IV }).toString();
    res.json(encrypted);
  },


//   encryption: function (response_data, callback) {
//     try {
//         let encrypted = CryptoJS.AES.encrypt(JSON.stringify(response_data), SECRET, { iv: IV }).toString();
//         callback(encrypted);

//     } catch (error) {
//         callback('');
//     }
// },

// /**
//  * Decrypt user request data
//  */
// decryption: function (req, callback) {
//     try {
//         if (req != undefined && Object.keys(req).length !== 0) {
//             let decrypted = JSON.parse(CryptoJS.AES.decrypt(req, SECRET, { iv: IV }).toString(CryptoJS.enc.Utf8));
//             callback(decrypted);

//         } else {
//             callback({});
//         }
//     } catch (error) {
//         callback('');
//     }
// },

//    /**
//      * Encrypt Plain
//      */
//     encryptPlain: function (data) {
//       try {
//           return CryptoJS.AES.encrypt(JSON.stringify(data), SECRET, { iv: IV }).toString();
//       } catch (e) {
//           return '';
//       }
//   },

//   /**
//    * Decrypt Plain
//    */
//   decryptPlain: function (data) {
//       try {
//           return JSON.parse(CryptoJS.AES.decrypt(data, SECRET, { iv: IV }).toString(CryptoJS.enc.Utf8));
//       } catch (e) {
//           return CryptoJS.AES.decrypt(data, SECRET, { iv: IV }).toString(CryptoJS.enc.Utf8);
//       }
//   },




  
}
module.exports = enc_dec
  