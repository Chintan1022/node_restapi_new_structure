const CryptoJS = require("crypto-js");
require("dotenv").config();
const SECRET = CryptoJS.enc.Hex.parse(process.env.KEY);
const IV = CryptoJS.enc.Hex.parse(process.env.IV);   
   
var enc_dec = {  

  decryptionDemo: function (req, res) {
    var request = JSON.parse(
      CryptoJS.AES.decrypt(req, SECRET, { iv: IV }).toString(CryptoJS.enc.Utf8)
    );
    res.json(request);
  },

  encryptionDemo: function (req, res) {
    var encrypted = CryptoJS.AES.encrypt(req, SECRET, { iv: IV }).toString();
    res.json(encrypted);
  },
  
}
module.exports = enc_dec
  