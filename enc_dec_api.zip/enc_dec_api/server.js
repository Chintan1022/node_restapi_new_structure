const express = require('express');
const enc_dec = require('./middleware/enc_dec')
require("dotenv").config();

// create express app
const app = express();

// Setup server port
const port = process.env.PORT || 5000;
/**
 * Code to parse request body
 */
app.use(express.text());
app.use(express.urlencoded({ extended: false}));


// Decryption
app.post('/decryption_demo', function (req, res) {
    console.log(req.body)
    enc_dec.decryptionDemo(req.body, res);
 });
 
 
 // Encryption
 app.post('/encryption_demo', function (req, res) {
     console.log(req.body)
     enc_dec.encryptionDemo(req.body, res);
 });


// listen for requests
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});



