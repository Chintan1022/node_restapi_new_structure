const cryptoLib = require('cryptlib');
const shaKey = cryptoLib.getHashSha256(process.env.KEY, 32);
const lang = require("./language");
const common = {

    sendResponse: async (req, res, resCode, msgKey, resData) => {
        const language = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "en-US,en;q=0.9,gu;q=0.8") ? req.headers['accept-language'] : 'en';
        if (lang[language] != undefined && lang[language][msgKey] != undefined) {
            msgKey = lang[language][msgKey]
        }
        var responsejson =
        {
            "message": msgKey

        }
        if (resData != null) {
            responsejson["data"] = resData;
        }
        const result = await common.encryption(responsejson);
        res.status(resCode).send(result)

    },

    decryption: async (req, res) => {
        try {
            if (req != undefined && Object.keys(req).length !== 0) {
                return await JSON.parse(cryptoLib.decrypt(req, shaKey, process.env.IV));
            }
            else {
                return ({})
            }
        } catch (error) {
            return await cryptoLib.decrypt(req, shaKey, process.env.IV);

        }
    },

    encryption: async (json_data) => {
        return await cryptoLib.encrypt(JSON.stringify(json_data), shaKey, process.env.IV);
    },

}

module.exports = common;