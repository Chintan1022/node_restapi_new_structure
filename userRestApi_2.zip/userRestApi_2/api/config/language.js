/** 
 * Load all the language file here
*/
var en = require('../language/en.json');

var Languages = {
	'en': en
}

module.exports = Languages;