const dbConn = require("../../../config/database");
const common = require("../../../config/common")


var user_model = {

    
    async getUsers(req,res) {
        try {
          const [rows, fields] = await dbConn.query(`select * from employees`);
          if(rows.length > 0){
            return await common.sendResponse(req,res,200,'text_user_get_all_users_succ', rows);
          }
          else{
            return await common.sendResponse(res,res,204,'text_user_not_found',null);
          }
        } catch (error) {
            return await common.sendResponse(res,res,500,'text_user_something_wrong',null);
        }
    },


    async createUser(req,res){
        console.log("reqqqqqqq",res)
        try {
            const result = await common.decryption(req.body)
            const [rows, fields] = await dbConn.query(`INSERT INTO employees SET ?`,result);
            if(rows != undefined){
             return await common.sendResponse(req,res,200,'text_user_create_succ', null);
            }
            else{
             return await common.sendResponse(req,res,204,'text_user_create_fail', null);
                
            }
        }
        catch (error) {
            return await common.sendResponse(req,res,500,'text_user_something_wrong',null);
        }
    },

    async updateUser(req,res){
        try {
            const result = await common.decryption(req.body)
            result.id = req.params.id;
            const [rows, fields] = await dbConn.query(`UPDATE employees SET ? WHERE id = ${result.id} `,result);
            if(rows != undefined){
             return await common.sendResponse(req,res,200,'text_user_update_user_succ', null);
            }
            else{
             return await common.sendResponse(req,res,204,'text_user_update_user_fail', null);
            }
       }
       catch (error) {
           return await common.sendResponse(req,res,500,'text_user_something_wrong',null);
       }
    },

    async deleteUser(req,res){
        try {
            const result = await common.decryption(req.body)
            result.id = req.params.id;
            const [rows, fields] = await dbConn.query(`DELETE FROM employees WHERE id = ${result.id}`,result);
            if(rows != undefined){
             return await common.sendResponse(req,res,200,'text_user_delete_user_succ', null);
            }
            else{
             return await common.sendResponse(req,res,204,'text_user_delete_user_fail', null);
            }
       }
       catch (error) {
           return await common.sendResponse(req,res,500,'text_user_something_wrong',null);
       }
    },


}

module.exports = user_model;