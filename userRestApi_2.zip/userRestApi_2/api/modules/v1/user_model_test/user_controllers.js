const user_model = require("./user_model");

exports.getUsers = async (req, res, next) => {
 return await user_model.getUsers(req,res)
};

exports.createUsers = async (req, res, next) => {
  return await user_model.createUser(req,res);
};

exports.updateUsers = async (req, res, next) => {
  return await user_model.updateUser(req,res);
};

exports.deleteUsers = async (req, res, next) => {
  return await user_model.deleteUser(req,res);
};
